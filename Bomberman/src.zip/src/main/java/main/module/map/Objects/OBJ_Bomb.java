package main.module.map.Objects;

import javafx.scene.canvas.GraphicsContext;
import main.module.map.GameCanvas;
import main.module.map.entities.Entity;
import main.module.map.tile.TileManager;

import java.awt.*;

public class OBJ_Bomb extends Entity {
    private int explodeCounter = 0;
    private boolean exploded = false;
    private final int explodeTime = 150;
    private final int range = 2;

    public OBJ_Bomb(GameCanvas gc) {
        super(gc);

        image = setup("/Images/Bombs/bomb");
        image2 = setup("/Images/Bombs/explode_center");
        image3 = setup("/Images/Bombs/explode_depth");
        image4 = setup("/Images/Bombs/explode_width");

        solidArea.x = 0;
        solidArea.y = 0;
        solidArea.width = gc.tileSize;
        solidArea.height = gc.tileSize;
        solidAreaDefaultX = 0;
        solidAreaDefaultY = 0;

        collision = false;
        type = 2;
    }

    public void update() {
        if (!exploded) {
            explodeCounter++;
            if (explodeCounter >= explodeTime) {
                exploded();
                exploded = true;
            }
        } else {
            explodeCounter++;
            if (explodeCounter >= explodeTime + 10) {
                gc.obj[findBombIndex()] = null;
            }
        }
    }

    private void exploded() {
        TileManager tileM = gc.tileM;
        int tileSize = gc.tileSize;

        int[] directionX = {0,0,-tileSize, tileSize};
        int[] directionY = {-tileSize,tileSize,0, 0};

        for (int i = 0; i < 4; i++) {
            int checkX = worldX + directionX[i];
            int checkY = worldY + directionY[i];
            int col = checkX / tileSize;
            int row = checkY / tileSize;

            if (col >= 0 && col < gc.maxWorldCol && row >= 0 && row < gc.maxWorldRow) {
                if (tileM.mapTileNum[col][row] == 3) {
                    tileM.mapTileNum[col][row] = 2;
                }
            }

            checkCollision(gc.player);
            for (Entity monster : gc.monsters) {
                if (monster != null) {
                    checkCollision(monster);
                }
            }
        }
    }

    private void checkCollision(Entity target) {
        int tileSize = gc.tileSize;
        Rectangle explosionArea = new Rectangle(worldX - tileSize, worldY - tileSize,
                tileSize * 3, tileSize * 3);
        target.solidArea.x = target.worldX + target.solidArea.x;
        target.solidArea.y = target.worldY + target.solidArea.y;

        if (explosionArea.intersects(target.solidArea)) {
            if (!target.invincible && target.life > 0) {
                target.life--;
                target.invincible = true;
            }
        }

        target.solidArea.x = target.solidAreaDefaultX;
        target.solidArea.y = target.solidAreaDefaultY;
    }

    private int findBombIndex() {
        for (int i = 0; i < gc.obj.length; i++) {
            if (gc.obj[i] == this) {
                return i;
            }
        }
        return -1;
    }

    public void draw(GraphicsContext g2) {
        int screenX = worldX - gc.player.worldX + gc.player.screenX;
        int screenY = worldY - gc.player.worldY + gc.player.screenY;

        if (worldX + gc.tileSize > gc.player.worldX - gc.player.screenX &&
                worldX - gc.tileSize < gc.player.worldX + gc.player.screenX &&
                worldY + gc.tileSize > gc.player.worldY - gc.player.screenY &&
                worldY - gc.tileSize < gc.player.worldY + gc.player.screenY) {

            if (!exploded) {
                g2.drawImage(image, screenX, screenY, gc.tileSize, gc.tileSize);
            } else {
                g2.drawImage(image2, screenX, screenY, gc.tileSize, gc.tileSize);
                g2.drawImage(image3, screenX, screenY - gc.tileSize, gc.tileSize, gc.tileSize*2);
                g2.drawImage(image3, screenX, screenY + gc.tileSize, gc.tileSize, gc.tileSize*2);
                g2.drawImage(image3, screenX - gc.tileSize, screenY, gc.tileSize, gc.tileSize*2);
                g2.drawImage(image3, screenX + gc.tileSize, screenY, gc.tileSize, gc.tileSize*2);
            }

        }
    }
}
