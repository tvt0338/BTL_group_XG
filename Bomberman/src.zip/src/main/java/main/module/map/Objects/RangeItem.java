package main.module.map.Objects;

import main.module.map.GameCanvas;
import main.module.map.entities.Entity;

public class RangeItem extends Entity {
    private int effectDuration = 300;
    private int effectCounter = 0;
    private boolean isActive = false;
    private int originalRange;

    public RangeItem(GameCanvas gc) {
        super(gc);
        image = setup("");
        solidArea.width = gc.tileSize;
        solidArea.height = gc.tileSize;
        solidAreaDefaultX = 0;
        solidAreaDefaultY = 0;
        collision = true;
        type = 3;
    }

    public void update() {
        if (isActive) {
            effectCounter++;
            if (effectCounter >= effectDuration) {
                isActive = false;
                effectCounter = 0;
            }
        }
    }

    public void applyEffect() {
        if (!isActive) {
            isActive = true;
        }
    }
}
