package main.module.map.SetPosition;

import main.module.map.GameCanvas;
import main.module.map.Objects.OBJ_Heart;
import main.module.map.Objects.RangeItem;
import main.module.map.Objects.SpeedItem;
import main.module.map.entities.Entity;
import main.module.map.monster.Balloon;
import main.module.map.monster.Fly;
import main.module.map.monster.Oneal;
import main.module.map.monster.Tanker;
import main.module.map.monster.Void;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Random;

public class AssetSetter {

    GameCanvas assetCanvas;

    public AssetSetter(GameCanvas assetCanvas) {
        this.assetCanvas = assetCanvas;
    }

    public void setObject() {
        Random random = new Random();
        List<int[]> spawnPoints = new ArrayList<>(assetCanvas.tileM.spawnPoints);
        Collections.shuffle(spawnPoints, random);
//        assetCanvas.obj[0] = new OBJ_Heart(assetCanvas);
//        assetCanvas.obj[0].worldX = assetCanvas.tileSize * 15;
//        assetCanvas.obj[0].worldY = assetCanvas.tileSize * 5;
//
//        assetCanvas.obj[1] = new OBJ_Heart(assetCanvas);
//        assetCanvas.obj[1].worldX = assetCanvas.tileSize * 2;
//        assetCanvas.obj[1].worldY = assetCanvas.tileSize * 11;

        int itemCount = Math.min(4, spawnPoints.size());
        int speedItemIndex = 0;
        int rangeItemIndex = 0;

        for (int i = 0; i < itemCount && i < spawnPoints.size(); i++) {
            int[] spawnPoint = spawnPoints.get(i);
            int col = spawnPoint[0];
            int row = spawnPoint[1];

            if (i % 2 == 0 && speedItemIndex < 2) {
                assetCanvas.obj[i + 2] = new SpeedItem(assetCanvas);
                assetCanvas.obj[i + 2].worldX = col * assetCanvas.tileSize;
                assetCanvas.obj[i + 2].worldY = row * assetCanvas.tileSize;
                speedItemIndex++;
            } else if (rangeItemIndex < 2) {
                assetCanvas.obj[i + 2] = new RangeItem(assetCanvas);
                assetCanvas.obj[i + 2].worldX = col * assetCanvas.tileSize;
                assetCanvas.obj[i + 2].worldY = row * assetCanvas.tileSize;
                rangeItemIndex++;
            }
        }

//        assetCanvas.obj[0] = new OBJ_Key(assetCanvas);
//        assetCanvas.obj[0].worldX = 23 * assetCanvas.tileSize;
//        assetCanvas.obj[0].worldY = 7 * assetCanvas.tileSize;
//
//        assetCanvas.obj[1] = new OBJ_Key(assetCanvas);
//        assetCanvas.obj[1].worldX = 23 * assetCanvas.tileSize;
//        assetCanvas.obj[1].worldY = 40 * assetCanvas.tileSize;
//
//        assetCanvas.obj[2] = new OBJ_Key(assetCanvas);
//        assetCanvas.obj[2].worldX = 38 * assetCanvas.tileSize;
//        assetCanvas.obj[2].worldY = 8 * assetCanvas.tileSize;
//
//        assetCanvas.obj[3] = new OBJ_Door(assetCanvas);
//        assetCanvas.obj[3].worldX = 10 * assetCanvas.tileSize;
//        assetCanvas.obj[3].worldY = 11 * assetCanvas.tileSize;
//
//        assetCanvas.obj[4] = new OBJ_Door(assetCanvas);
//        assetCanvas.obj[4].worldX = 8 * assetCanvas.tileSize;
//        assetCanvas.obj[4].worldY = 28 * assetCanvas.tileSize;
//
//        assetCanvas.obj[5] = new OBJ_Door(assetCanvas);
//        assetCanvas.obj[5].worldX = 12 * assetCanvas.tileSize;
//        assetCanvas.obj[5].worldY = 22 * assetCanvas.tileSize;
//
//        assetCanvas.obj[6] = new OBJ_Chest(assetCanvas);
//        assetCanvas.obj[6].worldX = 10 * assetCanvas.tileSize;
//        assetCanvas.obj[6].worldY = 7 * assetCanvas.tileSize;
//
//        assetCanvas.obj[7] = new OBJ_Boots(assetCanvas);
//        assetCanvas.obj[7].worldX = 37 * assetCanvas.tileSize;
//        assetCanvas.obj[7].worldY = 42 * assetCanvas.tileSize;
    }

    public void setNPC() {
//        assetCanvas.npc[0] = new NPC_OldMan(assetCanvas);
//        assetCanvas.npc[0].worldX = assetCanvas.tileSize*21;
//        assetCanvas.npc[0].worldY = assetCanvas.tileSize*21;
//        assetCanvas.monsters[0] = new Balloon(assetCanvas);
//        assetCanvas.monsters[0].worldX = assetCanvas.tileSize * 7;
//        assetCanvas.monsters[0].worldY = assetCanvas.tileSize * 6;
//
//
//        assetCanvas.monsters[1] = new Balloon(assetCanvas);
//        assetCanvas.monsters[1].worldX = assetCanvas.tileSize * 7;
//        assetCanvas.monsters[1].worldY = assetCanvas.tileSize * 12;
        Random random = new Random();
        List<int[]> spawnPoints = new ArrayList<>(assetCanvas.tileM.spawnPoints);
        Collections.shuffle(spawnPoints, random);

//        int monsterCount = 0;

        List<Class<? extends Entity>> weightedMonsters = new ArrayList<>();
        Collections.addAll(weightedMonsters, Fly.class,
                Balloon.class, Void.class, Oneal.class, Tanker.class);

        int numMonsters = Math.min(20, spawnPoints.size());
//        System.out.println("Số vị trí spawn khả dụng: " + spawnPoints.size());
//        System.out.println("Số quái  dự kiến spawn: " + numMonsters);
//
//        int flyCount = 0;
//        int maxFly = 10;
//        int balloonCount = 0;
//        int maxBalloon = 10;

        for (int i = 0; i < numMonsters; i++) {
            try {
                int[] spawnPoint = spawnPoints.get(i);
                int col = spawnPoint[0];
                int row = spawnPoint[1];
                Class<? extends Entity> monsterType = weightedMonsters.get(random.nextInt(weightedMonsters.size()));

//                if (flyCount < maxFly) {
//                    monsterType = Fly.class;
//                    flyCount++;
//                } else if (balloonCount < maxBalloon) {
//                    monsterType = Balloon.class;
//                    balloonCount++;
//                } else {
//                    monsterType = random.nextBoolean() ? Fly.class : Balloon.class;
//                }

                assetCanvas.monsters[i] = monsterType.getConstructor(GameCanvas.class).newInstance(assetCanvas);
                assetCanvas.monsters[i].worldX = col * assetCanvas.tileSize;
                assetCanvas.monsters[i].worldY = row * assetCanvas.tileSize;
//                monsterCount++;
                System.out.println("Spawn quai: " + monsterType.getSimpleName() + "tai (" + col + " " + row+ ")");

            } catch (Exception e) {
                e.printStackTrace();
                System.out.println("Loi spawn: " + i);
            }
        }

    }

}
