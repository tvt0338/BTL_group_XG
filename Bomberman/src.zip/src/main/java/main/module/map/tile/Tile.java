package main.module.map.tile;

import javafx.scene.image.Image;

public class Tile {
    public Image image;
    public boolean collision = false;
}
