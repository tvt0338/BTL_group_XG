package menu.screen_2;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Slider;
import javafx.stage.Stage;
import menu.music.music_menu;

import java.io.IOException;

public class SettingController {
    @FXML
    private Slider bgmSilder;
    @FXML
    private Button returnButton;

    public void returnToScreen(ActionEvent event) throws IOException {
        FXMLLoader switchToHelpScene = new FXMLLoader(getClass().getResource("/menu/Menu.fxml"));
        Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
        Scene scene = new Scene(switchToHelpScene.load());
        stage.setScene(scene);
        stage.show();
    }


    @FXML
    private void handleBGMVolume() {
        // Chỉ sử dụng bgmSlider để điều chỉnh âm lượng
        if (bgmSilder != null) {
            double volume = bgmSilder.getValue();
            music_menu.setVolume(volume);
        }
    }


}
