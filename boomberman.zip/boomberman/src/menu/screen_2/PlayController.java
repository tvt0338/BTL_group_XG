package menu.screen_2;

import javafx.animation.KeyFrame;
import javafx.animation.Timeline;
import javafx.fxml.FXML;
import javafx.scene.text.Text;
import javafx.util.Duration;

public class PlayController {

    @FXML
    private Text runningText;

    private Timeline timeline;

    public void setRunningText(String content) {
        runningText.setText("");  // Clear trước
        timeline = new Timeline();
        StringBuilder currentText = new StringBuilder();

        for (int i = 0; i < content.length(); i++) {
            final int index = i;
            KeyFrame keyFrame = new KeyFrame(Duration.millis(50 * (i + 1)), e -> {
                currentText.append(content.charAt(index));
                runningText.setText(currentText.toString());
            });
            timeline.getKeyFrames().add(keyFrame);
        }

        timeline.play();
    }
}
